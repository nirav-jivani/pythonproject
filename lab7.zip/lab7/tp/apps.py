from django.apps import AppConfig


class TpConfig(AppConfig):
    name = 'tp'
