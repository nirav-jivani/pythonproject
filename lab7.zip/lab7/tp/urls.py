from django.urls import url

from tp import views


urlpatterns = [
path('',views.get,name='home'),
]